<script>
	export default {
		onLaunch: function() {
			console.log('App Launch');
			// 每次启动 App 时，尝试从本地缓存恢复登录状态
			this.globalData.username = uni.getStorageSync('username') || '';
			this.globalData.token = uni.getStorageSync('token') || '';
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		},
		
		globalData:{
			page:'',
			username:'',
			token: '', // 🌟 新增：全局储存 token
		}
	}
</script>

<style>
	@import url("static/iconfont/iconfont.css");
	/*每个页面公共css */
</style>